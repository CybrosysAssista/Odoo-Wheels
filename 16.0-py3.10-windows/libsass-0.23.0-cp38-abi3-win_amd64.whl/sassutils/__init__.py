""":mod:`sassutils` --- Additional utilities related to Sass
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

This package provides several additional utilities related to Sass
which depends on libsass core (:mod:`sass` module).

"""
